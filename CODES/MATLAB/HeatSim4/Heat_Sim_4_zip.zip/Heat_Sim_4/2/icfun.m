function c0 = icfun(x)
c0 =0;
end